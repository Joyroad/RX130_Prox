/***********************************************************************
*
*  FILE        : Georgia_wires.c
*  DATE        : 2019-04-26
*  DESCRIPTION : Main Program
*
*  NOTE:THIS IS A TYPICAL EXAMPLE.
*
***********************************************************************/
#include "r_smc_entry.h"
#include "r_smc_entry.h"
#include "qe_common.h"
#include "r_touch_qe_if.h"
#include "qe_config01.h"
#include "r_cmt_rx_if.h"
#include "r_monitor.h"
#include "r_ctsu_qe_pinset.h"

void main(void);
/***********************************************************************************************************************
* Imported global variables and functions (from other files)
***********************************************************************************************************************/
bool    g_flag=false;
uint64_t    btn_states;
uint16_t    sldr_pos;
uint16_t    raw_buf[6];
uint16_t    dat_buf[6];
uint8_t     raw_cnt;

void main(void)
{
    qe_err_t    err;
    bool        success;
    uint32_t    cmt_ch;

    /* Setup pins */
    R_CTSU_PinSetInit();
	//R_Config_CMT0_Start();
	//R_Config_CMT1_Start();

    /* Open Touch driver */
    err = R_TOUCH_Open(gp_ctsu_cfgs, gp_touch_cfgs, QE_NUM_METHODS, QE_TRIG_SOFTWARE);
    if (err != QE_SUCCESS)
    {
        while(1) ;
    }

    /* Setup scan timer for 20ms (50Hz) */
    success = R_CMT_CreatePeriodic(50, qetouch_timer_callback, &cmt_ch);
    if (success == false)
    {
        while(1) ;
    }

    /* Main loop */
    while (1U)
    {
        if (g_qetouch_timer_flg == true)	//Fast Handler

        {
        	g_qetouch_timer_flg = false;
        	R_TOUCH_UpdateDataAndStartScan();
        	R_TOUCH_GetAllBtnStates(QE_METHOD_CONFIG01, &btn_states);
        	if((btn_states & 0x00000080)!=0)	// this is the hand wave antenna.
        	{

				PORT0.PODR.BIT.B6  = 0x00;
				PORT0.PODR.BIT.B7  = 0x00;
         	}
        	else
        	{
				PORT0.PODR.BIT.B6  = 0x01;
				PORT0.PODR.BIT.B7  = 0x01;
        	}
       	if((btn_states & 0x00001000)!=0)	// this is Key #2
        	{

				PORT0.PODR.BIT.B4  = 0x00;
         	}
        	else
        	{
				PORT0.PODR.BIT.B4  = 0x01;
        	}
       	if((btn_states & 0x00000800)!=0)	// this is the Key #1
        	{

				PORT2.PODR.BIT.B1  = 0x00;
         	}
        	else
        	{
				PORT2.PODR.BIT.B1  = 0x01;
        	}


        }
    }
}
